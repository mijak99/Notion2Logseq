# Root Page to Export to Logseq

This is a space to test logseq export / import

# Exporting the space

- Export root - with subpages, without folders, or 
Export root - with subpages, with folders
- Include Everything
- Use ‘default view’ for databases

![Untitled](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Untitled.png)

[Sub page](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Sub%20page%20f05b8540a06441b88c8a6b6026f2230b.md)

The root has a link to the [Sub page](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Sub%20page%20f05b8540a06441b88c8a6b6026f2230b.md) 

## Databases

[Page with an inline DB](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Page%20with%20an%20inline%20DB%20cbf9066f1f56421f973f935398b99803.md)

[Full page DB](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Full%20page%20DB%2019accaea7a6c42b1b569ca637746ba4b.csv)

[Tests to run on this](Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2/Tests%20to%20run%20on%20this%205a5e3a1b95de4c9e906428b1f4f2b6b2.md)