# Tests to run on this

# Tests

- [ ]  Check that links between  [Root Page to Export to Logseq](../Root%20Page%20to%20Export%20to%20Logseq%2041fb48ff63e848c8a9ccc2b4ade99fa2.md) and [Sub page](Sub%20page%20f05b8540a06441b88c8a6b6026f2230b.md) works both ways
- [ ]  Check that all 3 entries in the [](Page%20with%20an%20inline%20DB%20cbf9066f1f56421f973f935398b99803/Inline%20DB%20f412a77670364451886e9740197a26db.md) is exported (in spite of filtering)
- [ ]  Check that properties of the DB entries are shown in the file
- [ ]  Check that images on [Inline DB entry1](Page%20with%20an%20inline%20DB%20cbf9066f1f56421f973f935398b99803/Inline%20DB%20f412a77670364451886e9740197a26db/Inline%20DB%20entry1%20c5930b006e5f419a9ddbfb91c1e079a6.md) is OK
- [ ]  Check that image on [Sub page](Sub%20page%20f05b8540a06441b88c8a6b6026f2230b.md) is ok
- [ ]  Check that all todo’s on this page is Ok
- [ ]  Check that this link to [Not exported page](https://www.notion.so/Not-exported-page-34486a317a974ebfb9c7a8020f0662db?pvs=21) is
    - [ ]  a) linking to notion
    - [ ]  b) reported by the tool as not-transfered